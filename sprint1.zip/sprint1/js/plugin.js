(function($) {

$fn.bookPlugin = function(options) {

	var defaults = {
		contactsURL: 'data/contacts.json',
		output: #q
	}; // end default

	var options = $.extend(defaults, options);
	return this.each(function() {

	}
})


$(document).ready(function() {
	